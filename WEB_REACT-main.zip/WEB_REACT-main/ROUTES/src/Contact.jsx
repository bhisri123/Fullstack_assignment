import React from 'react';

const Contact = () => {
  return (
    <div>
      <h2>Contact</h2>
      <p>Feel free to contact us!</p>
    </div>
  );
};

export default Contact;